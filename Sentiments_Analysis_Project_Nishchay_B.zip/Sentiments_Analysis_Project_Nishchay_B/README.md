# Sentiments_Analysis
##NLP Project
##The client is in the business of Online Sale of Jewelry items through its
##website and also TV Channels in USA, UK and Australia. They receive multiple feedback
##and reviews of their products from all the channels, ( Website, TV Channels etc).

##The clients do not have a huge collection/ database of the reviews of their
##products, so there is a challenge of training the model for Sentiments Analysis.

##They want us to develop a dashboard, through which they can Analyze the reviews
##of their products and do a sentiment Analysis of it.

##Since there was a lack of enough data for training the model, we took a transfer
##learning approach to solve it. We took the Jewelry data from Amazon Reviews data until
##2018. It was 14 GB of JSON data.
